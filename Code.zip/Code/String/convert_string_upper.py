# You are given a string 'STR'. You have to convert the first alphabet of each word in a string to UPPER CASE.

# first approach. Big O(n) time and O(1) space complexity
def convert_string_upper(str):
    # You are given a string 'STR'. You have to convert the first alphabet of each word in a string to UPPER CASE.
    print(' '.join(word.capitalize() for word in str.split(' ')))


# second approach. Big O(n) time and O(n) space complexity
# def convert_string_upper(str):
#     str = list(str)
#     # check if first letter is small
#     if str[0] >= 'a':
#         str[0] = str[0].upper()

#     for i in range(1, len(str)):
#         if str[i] >= 'a' and str[i-1] == ' ':
#             str[i] = str[i].upper()
#     print(str)


convert_string_upper('the quick brown fox')
