# You are given a string 'str' and an integer 'D'.
# Your task is to rotate the given string left (anticlockwise) and right (clockwise) by 'D' units from the starting index.

def left_rotate(s, d):
    return s[d:] + s[:d]


def right_rotate(s, d):
    return s[-d:] + s[:-d]


print("left rotate", left_rotate('codingninjas', 2))
print("right rotate", right_rotate('codingninjas', 2))

# def leftRotate(strr, d):
#     # Write your code here.
#     left_rotate = strr[0:d]
#     strr.replace(strr[0:d], '')
#     strr = strr + left_rotate
#     print(strr)
#     return strr

# def rightRotate(strr, d):
#     # Write your code here.
#     right_rotate = strr[-d::]
#     strr.replace(strr[-d::], '')
#     strr = rightRotate + strr
#     print(strr)
#     return strr

# leftRotate("codingninjas", 2)
# rightRotate("codingninjas", 2)
