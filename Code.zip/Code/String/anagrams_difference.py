# Minimum Number of Manipulations required to make two Strings Anagram Without Deletion of Character

def anagramsDifference(str1, str2):
    
    count = 0

    # store the count of character
    char_count = [0] * 26

    for i in range(26):
        char_count[i] = 0

    # iterate though the first String
    # and update count
    for i in range(len(str1)):
        char_count[ord(str1[i]) -
                   ord('a')] += 1

  # iterate through the second String
    for i in range(len(str2)):
        # update char_count
        char_count[ord(str2[i]) - ord('a')] -= 1

    # if character is not found in
    # char_count then increase count
    for i in range(26):
        if char_count[i] != 0:
            count += abs(char_count[i])

    return int(count / 2)


print(anagramsDifference('buy', 'bye'))
