# minimum number of parentheses required to make a valid string

'''
Time complexity: O(n)
Space complexity: O(1); 'n' is no. of character in 'pattern' string.
'''


def minimumParentheses(pattern):

    openBr = 0    # To store count of '('
    closeBr = 0   # To store count of ')'
    count = 0     # Count of minimum parentheses required

    for i in range(len(pattern)):
        if(pattern[i] == '('):
            openBr += 1
        else:
            closeBr += 1

        # If ')' is greater than '('
        if(closeBr > openBr):
            count += (closeBr-openBr)
            openBr = 0
            closeBr = 0

    count += (openBr-closeBr)

    return count


print(minimumParentheses('(()))'))
