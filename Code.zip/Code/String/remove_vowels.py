# remove vowels from a string

def remove_vowels(string):
    return ''.join(c for c in string if c not in 'aeiouAEIOU')