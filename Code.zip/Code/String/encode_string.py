# For example, the string "aaaabbbccdaa" would be encoded as "a4b3c2d1a2".
from itertools import groupby

def encode(message):
    print(''.join('{}{}'.format(c, sum(1 for _ in g))
          for c, g in groupby(message)))
          
encode('aaaabbbccdaa')
