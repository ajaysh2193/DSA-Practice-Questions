l1 = ['abcd', 'abcde', 'abc14444', 'ab4', 'a', ] # Output: 'a'

def findsubstring(arr):
  s = arr[0]
  l = len(s)
  max_substring = ""
  for i in range(l):
    for j in range(i+1, l+1):
      stem = s[i:j]
      k = 1
      for k in range(0, len(arr)):
        
        if stem not in arr[k]:
          break
          
      if (k+1 ==  len(arr) or len(max_substring) < len(stem)):
        max_substring = stem
        
  return max_substring
  
print(findsubstring(l1))  