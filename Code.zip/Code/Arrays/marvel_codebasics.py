heros=['spider man','thor','hulk','iron man','captain america']

# print("Length of the list", len(heros))

heros.append('black panther')

# You realize that you need to add 'black panther' after 'hulk',
# so remove it from the list first and then add it after 'hulk'

heros.remove('black panther')
heros.insert(3,'black panther')

print(heros)

# you want to remove thor and hulk from list and replace them with doctor strange (because he is cool).
#    Do that with one line of code

heros[1:3]=['doctor strange']

print("heros list",heros.sort())