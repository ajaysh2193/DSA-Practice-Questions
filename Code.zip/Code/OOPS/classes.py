class Cookies:
    def __init__(self, color):
        self.color = color

    def get_color(self):
        return self.color

    def set_color(self, color):
        self.color = color


cookies_one = Cookies('red')
cookies_two = Cookies('blue')

print("Cookies one color is:", cookies_one.get_color())
print("Cookies two color is:", cookies_two.get_color())

cookies_one.set_color('green')

print("Cookies one color now is:", cookies_one.get_color())
print("Cookies two color still is:", cookies_two.get_color())
